<?php
/**
 * Created by PhpStorm.
 * User: Lewis
 * Date: 20/03/2017
 * Time: 23:56
 */

require_once "classes/Lab.php";

$lab = new Lab();

echo $lab->labTypeSelect();