<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js" xmlns="http://www.w3.org/1999/html"></script>
<link href="../../bootstrap/css/bootstrap.css" rel="stylesheet">
<script src="../../bootstrap/js/bootstrap.js"></script>

<div id="bottom-bar-code"  >
<!--    <nav class="navbar navbar-default navbar-fixed-bottom">-->
        <div class="container col-md-12">

                            <div class="col-md-4 col-md-offset-6 col-sm-offset-6">
                                <button class="btn btn-warning" onclick = "submit_new_lab()"; value="Create Lab">Create Lab</button>
                            </div>

        </div><!-- /.container-fluid -->
<!--    </nav>-->
</div>